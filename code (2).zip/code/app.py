from flask import Flask, request, render_template
import threading
import time
import logging

# ── Terminal Logging Setup (independent of Flask/Werkzeug) ──────────
log = logging.getLogger("RoboArm")
log.setLevel(logging.INFO)
if not log.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter(
        "%(asctime)s  %(levelname)-8s %(message)s",
        datefmt="%H:%M:%S"
    ))
    log.addHandler(_handler)
log.propagate = False  # Prevent Flask/Werkzeug from swallowing our logs

try:
    import RPi.GPIO as GPIO
    import board
    import busio
    from adafruit_pca9685 import PCA9685
    from adafruit_motor import servo
    MOCK_MODE = False
except ImportError:
    print("GPIO libraries not found. Running in MOCK MODE.")
    MOCK_MODE = True

app = Flask(__name__)

class RobotController:
    def __init__(self):
        # LEFT DRIVER
        self.L_DIR1, self.L_PWM1 = 5, 6
        self.L_DIR2, self.L_PWM2 = 13, 19
        # RIGHT DRIVER
        self.R_DIR1, self.R_PWM1 = 12, 16
        self.R_DIR2, self.R_PWM2 = 20, 21

        self.pins = [self.L_DIR1, self.L_PWM1, self.L_DIR2, self.L_PWM2,
                     self.R_DIR1, self.R_PWM1, self.R_DIR2, self.R_PWM2]
        
        self.current_speed = 60
        self.servos = []
        self._lock = threading.Lock()

        global MOCK_MODE
        if not MOCK_MODE:
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)
            for pin in self.pins:
                GPIO.setup(pin, GPIO.OUT)
            
            self.pwm_L1 = GPIO.PWM(self.L_PWM1, 1000)
            self.pwm_L2 = GPIO.PWM(self.L_PWM2, 1000)
            self.pwm_R1 = GPIO.PWM(self.R_PWM1, 1000)
            self.pwm_R2 = GPIO.PWM(self.R_PWM2, 1000)

            for pwm in [self.pwm_L1, self.pwm_L2, self.pwm_R1, self.pwm_R2]:
                pwm.start(0)

            try:
                self.i2c = busio.I2C(board.SCL, board.SDA)
                self.pca = PCA9685(self.i2c)
                self.pca.frequency = 50
                for i in range(5):
                    self.servos.append(servo.Servo(self.pca.channels[i]))
            except Exception as e:
                print(f"I2C Initialization failed: {e}")
                MOCK_MODE = True

    def set_speed(self, speed):
        with self._lock:
            self.current_speed = max(0, min(100, speed))
            log.info(f"⚡ Speed set to {self.current_speed}%")

    def move(self, direction):
        icons = {"forward": "⬆", "backward": "⬇", "left": "⬅", "right": "➡", "stop": "⏹"}
        icon = icons.get(direction, "?")

        if MOCK_MODE:
            log.info(f"{icon} [MOCK] Wheels: {direction.upper()} at {self.current_speed}%")
            return

        with self._lock:
            if direction == "forward":
                GPIO.output(self.L_DIR1, 1); GPIO.output(self.L_DIR2, 1)
                GPIO.output(self.R_DIR1, 1); GPIO.output(self.R_DIR2, 1)
                speed = self.current_speed
            elif direction == "backward":
                GPIO.output(self.L_DIR1, 0); GPIO.output(self.L_DIR2, 0)
                GPIO.output(self.R_DIR1, 0); GPIO.output(self.R_DIR2, 0)
                speed = self.current_speed
            elif direction == "left":
                GPIO.output(self.L_DIR1, 0); GPIO.output(self.L_DIR2, 0)
                GPIO.output(self.R_DIR1, 1); GPIO.output(self.R_DIR2, 1)
                speed = self.current_speed
            elif direction == "right":
                GPIO.output(self.L_DIR1, 1); GPIO.output(self.L_DIR2, 1)
                GPIO.output(self.R_DIR1, 0); GPIO.output(self.R_DIR2, 0)
                speed = self.current_speed
            else:  # stop
                GPIO.output(self.L_DIR1, 0); GPIO.output(self.L_DIR2, 0)
                GPIO.output(self.R_DIR1, 0); GPIO.output(self.R_DIR2, 0)
                speed = 0

            self.pwm_L1.ChangeDutyCycle(speed)
            self.pwm_L2.ChangeDutyCycle(speed)
            self.pwm_R1.ChangeDutyCycle(speed)
            self.pwm_R2.ChangeDutyCycle(speed)
            log.info(f"{icon} Wheels: {direction.upper()} | PWM duty: {speed}%")

    SERVO_NAMES = ["Base", "Shoulder", "Elbow", "Wrist", "Gripper"]

    def set_servo(self, index, angle):
        name = self.SERVO_NAMES[index] if index < len(self.SERVO_NAMES) else f"Servo{index}"
        clamped = max(0, min(180, angle))

        if MOCK_MODE:
            log.info(f"🦾 [MOCK] {name} (S{index+1}) → {clamped}°")
            return

        if 0 <= index < len(self.servos):
            try:
                self.servos[index].angle = clamped
                log.info(f"🦾 {name} (S{index+1}) → {clamped}°")
            except Exception as e:
                log.error(f"Servo {name} error: {e}")

robot = RobotController()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/move', methods=['POST'])
def move_route():
    direction = request.form.get('direction', 'stop')
    robot.move(direction)
    return ('', 204)

@app.route('/speed', methods=['POST'])
def speed_route():
    speed = int(request.form.get('speed', 60))
    robot.set_speed(speed)
    return ('', 204)

@app.route('/servo', methods=['POST'])
def servo_route():
    # Update only the servos that are sent
    for i in range(5):
        val = request.form.get(f's{i+1}')
        if val is not None:
            robot.set_servo(i, int(val))
    return ('', 204)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
